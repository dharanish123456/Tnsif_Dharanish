package com.dharanish.assignment5;

@SuppressWarnings("serial")
class InsufficientFundsException extends Exception {
 public InsufficientFundsException(String message) {
     super(message);
 }
}

