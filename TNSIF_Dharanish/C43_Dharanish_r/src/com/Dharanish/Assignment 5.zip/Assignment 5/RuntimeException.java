package com.Dharanish.assignment5;

@SuppressWarnings("serial")
class InvalidAmountException extends RuntimeException {
public InvalidAmountException(String message) {
   super(message);
}
}


